---
date: '2020-03-27'
title: 'Integrating Algolia Search with WordPress Multisite'
github: ''
external: 'https://medium.com/stories-from-upstatement/integrating-algolia-search-with-wordpress-multisite-e2dea3ed449c'
tech:
  - Algolia
  - WordPress
  - PHP
company: 'Upstatement'
showInProjects: true
---

Building a custom multisite compatible WordPress plugin to build global search with Algolia
