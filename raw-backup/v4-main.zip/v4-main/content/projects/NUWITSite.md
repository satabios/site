---
date: '2015-12-20'
title: 'NU Women in Tech'
github: 'https://github.com/nuwit/website'
external: 'https://nuwit.ccs.neu.edu/'
tech:
  - Jekyll
  - Bootstrap
company: 'Northeastern'
showInProjects: true
---

Complete overhaul and redesign of NU Women in Tech's club website using Jekyll, built while serving as web chair on the e-board.
