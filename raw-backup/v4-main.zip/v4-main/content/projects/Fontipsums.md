---
date: '2016-01-01'
title: 'Fontipsums'
github: 'https://github.com/bchiang7/fontipsums/'
external: 'http://bchiang7.github.io/fontipsums/'
tech:
  - HTML
  - SCSS
showInProjects: true
---

Simple website to display some of my favorite font pairings combined with some fun lorem ipsum variations found on the web.
