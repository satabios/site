---
date: '2020-08-02'
title: 'The 19th News'
github: ''
external: 'https://19thnews.org/'
tech:
  - WordPress
  - Timber
  - Gutenberg
  - PHP
  - JS
  - Mailchimp
  - AMP
company: 'Upstatement'
showInProjects: false
---
