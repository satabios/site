---
date: '2017-04-01'
title: 'Studio Developer'
company: 'Scout'
location: 'Northeastern University'
range: 'January - June 2017'
url: 'https://web.northeastern.edu/scout/'
---

- Collaborated with a small team of student designers to spearhead a new brand and design system for Scout’s inaugural student-led design conference at Northeastern
- Worked closely with designers and management team to develop, document, and manage the conference’s marketing website using Jekyll, Sass, and JavaScript
